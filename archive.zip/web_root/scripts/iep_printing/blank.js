
require(['jquery', 'handlebars'], function($, Handlebars) {

	$(document).ready(function() {
		
	});
	
});